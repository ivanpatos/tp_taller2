//Compilar con g++ test.cpp jsoncpp.cpp -o test

#include <cstdio>
#include <iostream>
#include "json/json.h"

using namespace std;

std::string kDBPath = "./database/";

int main() {

	//Creo json con username y password
	Json::Value valueInput(Json::objectValue);
	valueInput["username"] = "JuanPerez";
	valueInput["password"] = "holamundo";
	
	//Creo un string a partir del json
	Json::StreamWriterBuilder builder;
	builder.settings_["indentation"] = "\t";
	string input = Json::writeString(builder,valueInput);

	//Parseo un string y armo un json
	Json::Value valueOutput(Json::objectValue);
	Json::Reader reader;
	reader.parse(input, valueOutput);

	//Imprimo el json recuperado como un string
	string output = Json::writeString(builder,valueOutput);
	cout << output << endl;

	//recupero el valor del campo password
	string password = valueOutput.get("password", "").asString();
	cout << password << endl;
}

