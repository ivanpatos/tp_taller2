//Compilar con g++ hello_world.cpp jsoncpp.cpp mongoose.c -o hello_world
//En una terminal ejecutar esto, en otra el script de python (envia los http requests al server)

#include <string>
#include <iostream>
#include "json/json.h"
#include "mongoose.h"

using namespace std;

//Obtengo el value del header respectivo (identificado con name) del request http
string getValueFromRequestHeader(mg_connection *conn, const char* name){
	const char* header = mg_get_header(conn, name);
	if (header){
		string value(header);
		return value;
	}
	else
		return "";
}

//Obtengo la data del request http
string getDataFromRequest(mg_connection *conn){
	if (conn->content_len != 0){
		string data(conn->content, conn->content_len);
		return data;
	}
	else
		return "";
}


static int ev_handler(mg_connection *conn, mg_event ev) {

	switch (ev) {
		case MG_AUTH: 
			return MG_TRUE;
		case MG_REQUEST:
		{
			//Veo si la uri es "sarasa" (recurso segun REST)
			string uri(conn->uri);
			if (uri.compare("/sarasa") == 0)
			{	
				//Imprimo el user del header del request http que envia el cliente
				cout << "User: " << getValueFromRequestHeader(conn, "user") << " | ";
				//Imprimo el password del header del request http que envia el cliente
				cout << "Token: " << getValueFromRequestHeader(conn, "token") << endl;
				
				//Obtengo data del request http que envia el cliente 
				string stringMessageReceived = getDataFromRequest(conn);
				//Parseo el string y obtengo el json
				Json::Value jsonMessageReceived(Json::objectValue);
				Json::Reader reader;
				reader.parse(stringMessageReceived, jsonMessageReceived);
				//Obtengo cada par elemento: valor del json recibido
				cout << "Nombre: " << jsonMessageReceived["nombre"] << " | ";
				cout << "Apellido: " << jsonMessageReceived["apellido"] << " | ";
				cout << "Edad: " << jsonMessageReceived["edad"] << endl;
			
				//Creo un json de ejemplo para mandarle al cliente
				Json::Value jsonMessageToSend(Json::objectValue);
				jsonMessageToSend["mensaje1"] = "Funca...";
				jsonMessageToSend["mensaje2"] = "Hola mundo";
				Json::StreamWriterBuilder builder;
				builder.settings_["indentation"] = "\t";
				string stringMessageToSend = Json::writeString(builder,jsonMessageToSend);
				//Envia el json de ejemplo al cliente
				mg_printf_data(conn, stringMessageToSend.c_str());

				return MG_TRUE;
			}
			else
				return MG_TRUE;
		}
		default: 
			return MG_FALSE;
	}
}

int main(void) {

	mg_server *server;

	// Create and configure the server
	server = mg_create_server(NULL, ev_handler);
	mg_set_option(server, "listening_port", "8080");

	// Serve request. Hit Ctrl-C to terminate the program
	printf("Starting on port %s\n", mg_get_option(server, "listening_port"));
	for (;;) {
		mg_poll_server(server, 1000);
	}

	// Cleanup, and free server instance
	mg_destroy_server(&server);

	return 0;
}

