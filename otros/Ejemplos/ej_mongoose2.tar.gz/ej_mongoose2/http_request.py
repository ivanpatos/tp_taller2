#Ejecutar con pyhton http_request.py

import requests

headers={'user': 'juan123', 'token': '12345'}
json={'nombre': 'Juan', 'apellido': 'Perez', 'edad': '99'}
r = requests.post('http://localhost:8080/sarasa', json=json, headers=headers)

#print r.url
#print r.status_code
#print r.text
print r.json()
