//Ejemplo de la pagina de moongoose
//Compilar con g++ hello_world.cpp mongoose.c -o hello_world
//Luego de ejecutar ./hello_world entrar a un navegador y poner http://localhost:8080/sarasa
//Para cerrrar el server ctrol+c en la consola

#include <stdio.h>
#include <string.h>
#include "mongoose.h"

static int ev_handler(mg_connection *conn, mg_event ev) {
	switch (ev) {
		case MG_AUTH: 
			return MG_TRUE;
		case MG_REQUEST:
			mg_printf_data(conn, "Hello! Requested URI is [%s]", conn->uri);
			return MG_TRUE;
		default: 
			return MG_FALSE;
	}
}

int main(void) {

	mg_server *server;

	// Create and configure the server
	server = mg_create_server(NULL, ev_handler);
	mg_set_option(server, "listening_port", "8080");

	// Serve request. Hit Ctrl-C to terminate the program
	printf("Starting on port %s\n", mg_get_option(server, "listening_port"));
	for (;;) {
	mg_poll_server(server, 1000);
	}

	// Cleanup, and free server instance
	mg_destroy_server(&server);

	return 0;
}

