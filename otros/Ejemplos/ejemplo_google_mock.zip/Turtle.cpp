/*
 * Turtle.cpp
 *
 *  Created on: Sep 23, 2015
 *      Author: tomrea
 */

#include "Turtle.h"


Turtle::Turtle() {
	// TODO Auto-generated constructor stub

}

Turtle::~Turtle() {
	// TODO Auto-generated destructor stub
}
