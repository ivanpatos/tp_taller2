//Compilar con g++ proyecto.cpp -o proyecto -std=c++11 -lrocksdb -lpthread -lz -lbz2 -lsnappy

#include <cstdio>
#include <string>
#include <iostream>

#include "rocksdb/db.h"
#include "rocksdb/slice.h"
#include "rocksdb/options.h"

using namespace rocksdb;
using namespace std;

std::string kDBPath = "./database/";

int main() {
	DB* db;
	Options options;
	options.create_if_missing = true;
	Status s = DB::Open(options, kDBPath, &db);
	assert(s.ok());

	//Crea dos entradas
	s = db->Put(WriteOptions(), "key1", "value de key 1");
	assert(s.ok());
	s = db->Put(WriteOptions(), "key2", "value de key 2");
	assert(s.ok());
	
	//Averigua value de key 1
	string value;
	s = db->Get(ReadOptions(), "key1", &value);
	assert(s.ok());
	assert(value == "value de key 1");

	//Mete value de key 1 en key 2 (y borra la entrada de key 1)
	if (s.ok())
	{
		WriteBatch batch;
		batch.Delete("key1");
		batch.Put("key2", value);
		s = db->Write(WriteOptions(), &batch);
	}

	//Veo si existe key 2
	s = db->Get(ReadOptions(), "key2", &value);
	assert(!s.IsNotFound());

	//Uso un iterator para recorrer la DB
	Iterator* it = db->NewIterator(ReadOptions());
	for (it->SeekToFirst(); it->Valid(); it->Next())
		cout << it->key().ToString() << ": " << it->value().ToString() << endl;
	assert(it->status().ok());
	delete it;

	delete db;

	return 0;
}
